package cdac;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertEquals;

public class Simple7CharValidatorTest {
    private WebDriver driver;

    @Before
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }

    @Test
    public void testSevenCharValidation() {
        driver.get("https://testpages.eviltester.com/styled/apps/7charval/simple7charvalidator.html");

        WebElement input = driver.findElement(By.id("validatorinput"));
        input.sendKeys("abcdefg"); // 7 chars

        WebElement button = driver.findElement(By.id("validatebutton"));
        button.click();

        WebElement result = driver.findElement(By.id("resultmessage"));
        assertEquals("Input Accepted", result.getText().trim());
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}