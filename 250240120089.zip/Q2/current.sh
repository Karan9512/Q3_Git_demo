for file in n *; do
  if [ -f "$file" ] && [ -x "$file" ]; then
    echo "$file"
  fi
done
